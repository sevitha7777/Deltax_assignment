A music app similar to gaana and jiosaavan in Django.
